import React, { Component } from 'react';
import BusinessSegmentService from '../service/BusinessSegmentService';

class AddBusiSegmentComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            bus_seg_id : '',
            bus_seg_seq : '',
            bus_seg_name : ''
        }
        this.saveSegment = this.saveSegment.bind(this);
    }
    saveSegment = (seg) => {
        seg.preventDefault();
        let segment = {
            bus_seg_id : this.state.bus_seg_id,
            bus_seg_seq : this.state.bus_seg_seq,
            bus_seg_name : this.state.bus_seg_name
        };
        BusinessSegmentService.addBusinessSegment(segment).then(res=> {
            this.setState({message : "Segment added sucessfully"});
            this.props.history.push("/segments");
        });
    }
    onChange = (seg) => this.setState({[seg.target.name] : seg.target.value});

    render() {
        return(
            <div>
                <h1>Add Business Segment</h1>
                <form>
                    <div className="form-group">
                        <label>Segment ID</label>
                        <input type="text" name="bus_seg_id" className="form-control" value={this.state.bus_seg_id} onChange={this.onChange}></input><br></br>
                        <label>Segment SEQ</label>
                        <input type="text" name="bus_seg_seq" className="form-control" value={this.state.bus_seg_seq} onChange={this.onChange}></input><br></br>
                        <label>Segment NAME</label>
                        <input type="text" name="bus_seg_name" className="form-control" value={this.state.bus_seg_name} onChange={this.onChange}></input><br></br>
                    </div>
                    <button className="btn btn-success" onClick={this.saveSegment}>Save</button>
                </form>
            </div>
        );
    }
}

export default AddBusiSegmentComponent;
