import axios from 'axios';

const SEGURL = "http://localhost:8282/segments";

class BusinessSegmentService {
    getBusinessSegments() {
        return axios.get(SEGURL);
    }

    getSegmentById(seg_id){
        return axios.get(SEGURL+"/"+seg_id);
    }
    addBusinessSegment(segment) {
        return axios.post(""+SEGURL,segment);
    }

    editBusinessSegment(segment) {
        return axios.put(SEGURL,segment);
    }
    deleteBusinessSegement(seg_id){
        return axios.delete(SEGURL+"/"+seg_id);
    }
}

export default new BusinessSegmentService();