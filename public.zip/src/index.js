import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { Provider } from 'react-redux';
import configureStore from './store/configStore';

const StoreInstance = configureStore();

ReactDOM.render(
  <Provider store={StoreInstance}>
			<App />
	</Provider>,
  document.getElementById('root')
);


