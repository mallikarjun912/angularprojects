import axios from 'axios';

const ROLEURL = "http://localhost:8282/login";

export const loginSuccess = (userrole) => {
    console.log("inside success action");
    console.log(userrole);
    return {
        type: 'LOGIN_SUCCESS',userrole 
     }
};

export const doLogin = (payload) => {
    console.log("inside doLogin");
 //  return(dispatch) => {
        let data = {
            username : payload.username,
            password : payload.password
        }
       return (dispatch) => { // added this line which was missing and changed to post req
       //    return axios.get(ROLEURL+"/"+username+"/"+password)
        return axios.post(ROLEURL+'/',data)
            .then(Response =>{
                localStorage.setItem("user",JSON.stringify(Response.data));
                console.log("api call");
                dispatch(loginSuccess(Response.data));
            })
            .catch(Error => {
                console.log("error");
                throw(Error);
            });
   };
};